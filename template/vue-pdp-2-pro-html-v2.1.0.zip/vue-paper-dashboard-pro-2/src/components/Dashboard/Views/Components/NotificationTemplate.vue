<template>
  <span>Welcome to <b>Paper Dashboard</b> - a beautiful freebie for every web developer.</span>
</template>
<script>
  export default {}
</script>
<style>
</style>
